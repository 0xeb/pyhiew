import hiew

hiew.Message("Hi", "Hello world!")