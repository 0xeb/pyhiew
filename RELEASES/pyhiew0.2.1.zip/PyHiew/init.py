import hiew

# Set startup script information
#hiew.SetStarupScript('test.py', globals(), 'testMain')
hiew.SetStarupScript('scriptbrowser.py', globals(), 'ScriptBrowserMain')