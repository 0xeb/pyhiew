import hiew

# Set startup script information
#hiew.SetStartupScript('test.py', globals(), 'testMain')
hiew.SetStartupScript('scriptbrowser.py', globals(), 'ScriptBrowserMain')