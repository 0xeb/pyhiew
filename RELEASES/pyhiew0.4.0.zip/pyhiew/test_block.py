import hiew

dbg = hiew.dbg

hiew.UnmarkBlock()

hiew.Message("Info", "Unmarked previous block")

hiew.MarkBlock(0, 100)

