import hiew

dbg = hiew.dbg

s = hiew.GetString("Enter string", 50)

hiew.Message("You entered:", s)