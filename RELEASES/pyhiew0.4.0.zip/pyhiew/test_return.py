import hiew


# or:

hiew.ReturnMode(hiew.HEM_RETURN_MODE_CODE)

# or:

#hiew.ReturnOffset(0x17)
